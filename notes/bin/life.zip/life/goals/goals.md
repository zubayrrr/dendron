---

kanban-plugin: basic

---

## Physical



## Knowledge



## Life

- [ ] [[Study in USA|Study in Canada]]


## Professional



## Wealth





%% kanban:settings
```
{"kanban-plugin":"basic","metadata-keys":[{"metadataKey":"Progress","label":"","shouldHideLabel":false,"containsMarkdown":false},{"metadataKey":"Target","label":"","shouldHideLabel":false,"containsMarkdown":false},{"metadataKey":"Timespan","label":"","shouldHideLabel":false,"containsMarkdown":true},{"metadataKey":"Reason","label":"","shouldHideLabel":false,"containsMarkdown":true},{"metadataKey":"Bar","label":"","shouldHideLabel":true,"containsMarkdown":true},{"metadataKey":"Projects","label":"","shouldHideLabel":true,"containsMarkdown":true}]}
```
%%