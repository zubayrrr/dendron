---

kanban-plugin: basic

---

## Todo



## Waiting



## In Progress



## Completed

- [ ] [[Get your IELTS|Get your IELTS]]


## Discarded





%% kanban:settings
```
{"kanban-plugin":"basic","metadata-keys":[{"metadataKey":"subtitle","label":"","shouldHideLabel":true,"containsMarkdown":true},{"metadataKey":"goal","label":"Goal","shouldHideLabel":false,"containsMarkdown":true}]}
```
%%