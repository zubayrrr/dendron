---
created: 20220104200838113
modified: 20220104201420107
title: NY Resolutions
---

- Practice Scala - Finish all exercises on [w3resource](https://www.w3resource.com/scala-exercises/)

