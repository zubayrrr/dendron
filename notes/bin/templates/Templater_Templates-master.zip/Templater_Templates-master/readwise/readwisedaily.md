<%*
const readwiseToken = "INSERT_YOUR_TOKEN_HERE";
const output = await tp.user.readwise(tp, readwiseToken, true);
if (output) tR = output;
%>